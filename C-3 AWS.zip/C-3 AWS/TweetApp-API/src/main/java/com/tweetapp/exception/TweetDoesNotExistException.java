package com.tweetapp.exception;

public class TweetDoesNotExistException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -179246759582276729L;

	public TweetDoesNotExistException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

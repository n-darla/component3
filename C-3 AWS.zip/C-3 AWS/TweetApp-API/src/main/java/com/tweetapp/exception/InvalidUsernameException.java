package com.tweetapp.exception;

public class InvalidUsernameException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5966130919267770338L;

	public InvalidUsernameException(String msg){
		super(msg);
	}
	
}
